DROP TABLE IF EXISTS `#__auth_user`;
DROP TABLE IF EXISTS `#__auth_role`;
DROP TABLE IF EXISTS `#__auth_rule`;

